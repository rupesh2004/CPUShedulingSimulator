import java.awt.*;
import javax.swing.*;
import javax.swing.text.AttributeSet.ColorAttribute;

import java.awt.event.*;
 class FCFS extends JFrame implements ActionListener
{
    JLabel la1,la2;
    JLabel lb1,lb2;
    JButton b1;
    JTextField ta1;
    JPanel p1,p2;
JLabel l[];
JLabel lp[],lat[],lbt[],lct[],lwt[];

JTextField t[]=null;
 JTextField tb[]=null;	
 int n;



    public FCFS()
    {
        setVisible(true);
        setSize(900,900);
        setLayout(null);

       
        n=Integer.parseInt(JOptionPane.showInputDialog("enter num of process"));
        
                      p1=new JPanel();
      	    p1.setBounds(0,0,900,900);

          			add(p1);
          			p1.setLayout(null);
			  p2=new JPanel();
			 
      	    		  p2.setBounds(0,0,900,900);

          
          			lb1=new JLabel("ARRIVALTIME");
           			lb2=new JLabel("BRUSTTIME");
            
            			lb1.setBounds(250,50,100,50);
            			lb2.setBounds(400,50,100,50);
            			p1.add(lb1);
            			p1.add(lb2);
			b1=new JButton("ok");
			b1.setBounds(600,300,100,50);

			lb1=new JLabel("ARRIVALTIME");
           			lb2=new JLabel("BRUSTTIME");
            
            			lb1.setBounds(250,50,100,50);
            			lb2.setBounds(400,50,100,50);
            			p1.add(lb1);
            			p1.add(lb2);
         
          
     			l=new JLabel[n];
          			t=new JTextField[n];
           			tb=new JTextField[n];
          			int x=100,y=100;
          			int x1=250,y1=100;
           			int x2=400,y2=100;
          			for(int i=0;i<n;i++)
       			   {
            				l[i]=new JLabel("process:"+i);
            				l[i].setBounds(x,y,100,50);
            				p1.add(l[i]);
          				  t[i]=new JTextField();
            				  t[i].setBounds(x1,y1,100,50);
 				           p1.add(t[i]);
            
           				 tb[i]=new JTextField();
            				tb[i].setBounds(x2,y2,100,50);
           				 p1.add(tb[i]);
            
            
           				 y=y+100;
            				y1=y1+100;
            				y2=y2+100;
           
          				}
			p1.add(b1);
      
  			    b1.addActionListener(this);
        
    
    }

   public void actionPerformed(ActionEvent ae)
	{
		
		
				int at[ ]=new int[n];
				int bt[ ]=new int[n];
				int pid[ ]=new int[n];
				int ct[]=new int[n];
				int ta[]=new int[n];
				int wt[]=new int[n];
				int avgwt=0,avgta=0;

 				
				for(int i=0;i<n;i++)
				{
				
					at[i]=Integer.parseInt(t[i].getText());
					bt[i]=Integer.parseInt(tb[i].getText());
						pid[i]=i+1;
			                 }
				
				JOptionPane.showMessageDialog(this,"value get");
                                                            		int temp;
                                                             		for(int i=0;i<n;i++)
					{
						for(int j=0;j<(n-(i+1));j++)
						{
							   if(at[j]>at[j+1])
							{
								temp=at[j];
								at[j]=at[j+1];
								at[j+1]=temp;
							
								temp=bt[j];
								bt[j]=bt[j+1];
								bt[j+1]=temp;
							
								temp=pid[j];
								pid[j]=pid[j]+1;
								pid[j+1]=temp;
								}
						}
					}
				JOptionPane.showMessageDialog(this,"value sorted");

			
				for(int i=0;i<n;i++)
				{
					if(i==0)
					{
						ct[i]=at[i]+bt[i];
					}
					else
					{
						if(at[i]>ct[i-1])
						{ 
							ct[i]=at[i]+bt[i];
						}
						else
						{
							ct[i]=ct[i-i]+bt[i];
						}
                                                                                                      ta[i]=ct[i]-at[i];
						wt[i]=ta[i]-bt[i];
                                                                                                       avgwt=avgwt+wt[i];
						avgta=avgta+ta[i];



					}
				}
				


			JLabel l1,l2,l3,l4,l5,ll6;
			
			l1=new JLabel("PID");
			l1.setForeground(Color.RED);
			l1.setFont(new Font("Verdana", Font.BOLD, 18));
			l2=new JLabel("AT");
			l2.setFont(new Font("Verdana", Font.BOLD, 18));
			l2.setForeground(Color.RED);		
			l3=new JLabel("BT");
			l3.setFont(new Font("Verdana", Font.BOLD, 18));
			l3.setForeground(Color.RED);
			l4=new JLabel("TAT");
			l4.setFont(new Font("Verdana", Font.BOLD, 18));
			l4.setForeground(Color.RED);
			l5=new JLabel("WT");
			l5.setFont(new Font("Verdana", Font.BOLD, 18));
			l5.setForeground(Color.RED);
			ll6=new JLabel("--------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			p1.setVisible(false);
			p2.setLayout(null);
			l1.setBounds(100,100,100,50);
			l2.setBounds(250,100,100,50);
			l3.setBounds(400,100,100,50);
			l4.setBounds(550,100,100,50);
			l5.setBounds(700,100,100,50);
			ll6.setBounds(80,150,800,50);

			
			p2.add(l1);
			p2.add(l2);
			p2.add(l3);
			p2.add(l4);
			p2.add(l5);
			p2.add(ll6);

			 lp=new JLabel[n];
			int xl1=100,yl1=200;
			for(int i=0;i<n;i++)
			{

				lp[i]=new JLabel(" "+pid[i]);
				lp[i].setBounds(xl1,yl1,100,50);
				lp[i].setFont(new Font("Verdana", Font.BOLD, 18));
				
				p2.add(lp[i]);
				yl1=yl1+100;
			}
			
			lat=new JLabel[n];
			int xl2=250,yl2=200;
			for(int i=0;i<n;i++)
			{

				lat[i]=new JLabel(" "+at[i]);
				lat[i].setBounds(xl2,yl2,100,50);
				lat[i].setFont(new Font("Verdana", Font.BOLD, 18));
				
				p2.add(lat[i]);
				yl2=yl2+100;
			}

			lbt=new JLabel[n];
			int xl3=400,yl3=200;
			for(int i=0;i<n;i++)
			{

				lbt[i]=new JLabel(" "+bt[i]);
				lbt[i].setBounds(xl3,yl3,100,50);
				lbt[i].setFont(new Font("Verdana", Font.BOLD, 18));
				
				p2.add(lbt[i]);
				yl3=yl3+100;
			}

			lct=new JLabel[n];
			int xl4=550,yl4=200;
			for(int i=0;i<n;i++)
			{

				lbt[i]=new JLabel(" "+ct[i]);
				lbt[i].setBounds(xl4,yl4,100,50);
				lbt[i].setFont(new Font("Verdana", Font.BOLD, 18));
				
				p2.add(lbt[i]);
				yl4=yl4+100;
			}
			lwt=new JLabel[n];
			int xl5=700,yl5=200;
			for(int i=0;i<n;i++)
			{

				lbt[i]=new JLabel(" "+wt[i]);
				lbt[i].setBounds(xl5,yl5,100,50);
				lbt[i].setFont(new Font("Verdana", Font.BOLD, 18));
				
				p2.add(lbt[i]);
				yl5=yl5+100;
			}
			

			
			//p2.setVisible(true);
			add(p2);
		
			
	




			}
        
			public static void main(String[] args) {
				new FCFS();	
			}
    
		

	

	


}





