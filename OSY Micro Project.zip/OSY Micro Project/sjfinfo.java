import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
 class sjfinfo extends JFrame implements ActionListener

{
      
    JButton b1,b2;

JLabel l1,l2;
          public sjfinfo()

  {

        setVisible(true);
        setSize(900,900);
        setLayout(null);
      b1=new JButton("Solve Examples of SJF");
      b1.setBounds(130,350,300,50);
      add(b1);

      b2=new JButton("INFO");
      b2.setBounds(530,350,300,50);
      add(b2);

      l2=new JLabel("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
      l2.setBounds(100,300,800,20);
      add(l2);

      ImageIcon im=new ImageIcon("sjf.jpeg");
      l1=new  JLabel(im);
      l1.setBounds(0,0,900,900);
      add(l1);


      b1.addActionListener(this);
      b2.addActionListener(this);
  }

                
          

          public void actionPerformed(ActionEvent ae){
              String s=ae.getActionCommand();

              if(s.equals("Solve Examples of SJF")){
              
                sjf2 s1=new sjf2();
              }
              if(s.equals("INFO")){
                File fr=new File("sjf.pdf");
                try{
                if(fr.exists())  
                  {
                      if(Desktop.isDesktopSupported())
                           Desktop.getDesktop().open(fr);
                       else
                          JOptionPane.showMessageDialog(null,"not supported");
  
                  }
              else{
                  JOptionPane.showMessageDialog(null,"file not exists");
              }
  
       }catch(Exception e){}
  
              }
          }
          public static void main(String[] args) {
              sjfinfo s1=new sjfinfo();
          }
}
