import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
 class rrinfo extends JFrame implements ActionListener

{
      
    JButton b1,b2;

    JLabel l1;
    ImageIcon i1;

          public rrinfo()

  {

        setVisible(true);
        setSize(900,900);
        setLayout(null);
      b1=new JButton("Solve Examples of RR");
      b1.setBounds(320,300,250,50);
      add(b1);

      b2=new JButton("INFO");
      b2.setBounds(320,400,250,50);
      add(b2);

      i1=new ImageIcon(new ImageIcon("rr.jpeg").getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
      l1=new  JLabel(i1);
      l1.setBounds(0,0,900,900);
      add(l1);

      b1.addActionListener(this);
      b2.addActionListener(this);
  }

                
          

          public void actionPerformed(ActionEvent ae){
              String s=ae.getActionCommand();

              if(s.equals("Solve Examples of RR")){
              
                RR r=new RR();
              }
              if(s.equals("INFO")){
                File fr=new File("rr.pdf");
                try{
                if(fr.exists())  
                  {
                      if(Desktop.isDesktopSupported())
                           Desktop.getDesktop().open(fr);
                       else
                          JOptionPane.showMessageDialog(null,"not supported");
  
                  }
              else{
                  JOptionPane.showMessageDialog(null,"file not exists");
              }
  
       }catch(Exception e){}
  
              }
          }
          public static void main(String[] args) {
            rrinfo rf1=new rrinfo();
          }
}
