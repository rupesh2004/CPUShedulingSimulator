//shree tuljabhavani prasanna
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class cpusched extends JFrame implements ActionListener
{
    JButton b1,b2,b3;
	JLabel l1;
	ImageIcon i1;
     public cpusched()
	{
		setVisible(true);
		setSize(900,900);
		setLayout(null);
		

		i1=new ImageIcon(new ImageIcon("cpu.jpg").getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT));
		l1=new  JLabel(i1);
		l1.setBounds(0,0,900,900);
		add(l1);

		b1=new JButton("FCFS");
		b2=new JButton("SJF");
		b3=new JButton("RR");

		b1.setBounds(600,400,200,50);
		b2.setBounds(600,500,200,50);
		b3.setBounds(600,600,200,50);
		l1.add(b1);
		l1.add(b2);
		l1.add(b3);
		b1.setBackground( Color.decode("#D47AE8") );
		b2.setBackground( Color.decode("#00BCD4") );
		b3.setBackground( Color.decode("#FF8E00") );

		add(l1);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
	
	}
	public void actionPerformed(ActionEvent ae)
	{

		String s=ae.getActionCommand();
		if(s.equals("FCFS"))
		{
		FCFSMain f1=new FCFSMain();
		}
		if(s.equals("RR"))
		{
			rrinfo rf1=new rrinfo();
		}
        if(s.equals("SJF"))
		{
			sjfinfo s1=new sjfinfo();
		}
		
	}
	public static void main(String args[])
	{
	cpusched cp=new cpusched();
	}
}

    
