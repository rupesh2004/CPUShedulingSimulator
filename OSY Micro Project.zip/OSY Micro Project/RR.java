import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
  public class RR  extends Frame implements ActionListener
{
   // JLabel la1,la2;
    JLabel lb2;
    JButton b1;
    JTextField tb1;
    JPanel p1,p2;
JLabel l[];
JLabel lp[],lat[],lbt[],lct[],lwt[];
JTextField t[]=null;
JTextField tb[]=null;	
 int n,sum;
Font f;
public RR()
    {
        setVisible(true);
        setSize(900,900);
        setLayout(null);

        n=Integer.parseInt(JOptionPane.showInputDialog("enter num of process"));
       	 p1=new JPanel();
     	 p1.setBounds(0,0,900,900);
	 p2=new JPanel();
     	 p2.setBounds(0,0,900,900);

	add(p1);
          	p1.setLayout(null);
	lb2=new JLabel("BRUSTTIME");
                 lb2.setBounds(250,50,100,50);
              f=new Font("Arial",Font.BOLD,24);
            			p1.add(lb2);
			b1=new JButton("ok");
			b1.setBounds(600,300,100,50);
			l=new JLabel[n];
          			tb=new JTextField[n];
          			int x=100,y=100;
          			int x2=250,y2=100;
          			for(int i=0;i<n;i++)
       			   {
            				l[i]=new JLabel("process:"+i);
            				l[i].setBounds(x,y,100,50);
            				p1.add(l[i]);
          				 
      				 tb[i]=new JTextField();
            				tb[i].setBounds(x2,y2,100,50);
           				 p1.add(tb[i]);
            
      				 y=y+100;
            				y2=y2+100;
           			     }
			p1.add(b1);
     			b1.addActionListener(this);
        
    
    }

  public void actionPerformed(ActionEvent ae)
	{
		int i,j,k;
		
				int bt[]=new int[n];
				int wt[]=new int[n];
				int tat[]=new int[n];
				int a[]=new int[n];
 				
				for( i=0;i<n;i++)
				{
						bt[i]=Integer.parseInt(tb[i].getText());
						
			      }
				
				JOptionPane.showMessageDialog(this,"value get");
                                                            		
		
		int q=Integer.parseInt(JOptionPane.showInputDialog("Enter Time quantum:"));
		for( i=0;i<n;i++)
			a[i]=bt[i];
		for(i=0;i<n;i++)
			wt[i]=0;
		do{
		for(i=0;i<n;i++){
			if(bt[i]>q){
				bt[i]-=q;
				for(j=0;j<n;j++){
					if((j!=i)&&(bt[j]!=0))
					wt[j]+=q;
				}
			}
			else{
				for(j=0;j<n;j++){
					if((j!=i)&&(bt[j]!=0))
					    wt[j]+=bt[i];
				}
				bt[i]=0;
			}
		}
		sum=0;
		for(k=0;k<n;k++)
			sum=sum+bt[k];
		}
        while(sum!=0);
        
		for(i=0;i<n;i++)
			tat[i]=wt[i]+a[i];
            
		
	

			JLabel l1,l2,l3,l4,l5;
			
			l1=new JLabel("Process");
			l2=new JLabel("BT");
			l3=new JLabel("WT");
			l4=new JLabel("TAT");
			l5=new JLabel("---------------------------------------------------------------------------------------");
			l1.setFont(f);
			l2.setFont(f);
			l3.setFont(f);
			l4.setFont(f);
			l5.setFont(f);
			p1.setVisible(false);
			p2.setLayout(null);
			l1.setBounds(100,100,100,50);
			l2.setBounds(250,100,100,50);
			l3.setBounds(400,100,100,50);
			l4.setBounds(550,100,100,50);
			l5.setBounds(100,150,600,50);
			p2.add(l1);
			p2.add(l2);
			p2.add(l3);
			p2.add(l4);
			p2.add(l5);

			 lp=new JLabel[n];
			int xl1=50,yl1=200;
			for(i=0;i<n;i++)
			{

				lp[i]=new JLabel("Process- "+i);
				lp[i].setBounds(xl1,yl1,200,50);
				lp[i].setForeground(Color.red);
				lp[i].setFont(f);
				
				p2.add(lp[i]);
				yl1=yl1+100;
			}
			
			lat=new JLabel[n];
			int xl2=250,yl2=200;
			for( i=0;i<n;i++)
			{

				lat[i]=new JLabel(" "+a[i]);
				lat[i].setBounds(xl2,yl2,100,50);
				lat[i].setForeground(Color.blue);
				lat[i].setFont(f);
				
				p2.add(lat[i]);
				yl2=yl2+100;
			}

			lbt=new JLabel[n];
			int xl3=400,yl3=200;
			for( i=0;i<n;i++)
			{

				lbt[i]=new JLabel(" "+wt[i]);
				lbt[i].setBounds(xl3,yl3,100,50);
				lbt[i].setForeground(Color.cyan);
				lbt[i].setFont(f);
				
				
				p2.add(lbt[i]);
				yl3=yl3+100;
			}

			lct=new JLabel[n];
			int xl4=550,yl4=200;
			for( i=0;i<n;i++)
			{

				lct[i]=new JLabel(" "+tat[i]);
				lct[i].setBounds(xl4,yl4,100,50);
				lct[i].setForeground(Color.green);
				lct[i].setFont(f);
				
				p2.add(lct[i]);
				yl4=yl4+100;
			}
			
			

			
			//p2.setVisible(true);
			add(p2);
		
			
	



			}
        public static void main(String args[])
	{

		RR r=new RR();
	}

    
		

	

	


}





