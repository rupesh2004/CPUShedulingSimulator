    import java.awt.*;
    import javax.swing.*;
    import java.awt.event.*;
    class FCFSMain extends JFrame implements ActionListener
    {
            JLabel l1;
            JButton b1,b2;
            ImageIcon im;

            public FCFSMain()
            {

                setVisible(true);
                setSize(1200,900);
                setLayout(null);

                im=new ImageIcon("fcfs12.jpg");
                l1=new JLabel(im);
                b1=new JButton("Solve EXample of FCFS");
                b2=new JButton("info");
                l1.setBounds(0,0,1200,900);
                b1.setBounds(500,100,300,50);
                b2.setBounds(500,200,300,50);
                l1.add(b1);
                l1.add(b2);
                add(l1);
                b1.addActionListener(this);
        b2.addActionListener(this);
            }
            public void actionPerformed(ActionEvent ae)
            {
                String s=ae.getActionCommand();
                if(s.equals("Solve EXample of FCFS"))
                {
                        FCFS f1=new FCFS();
                    }

        if(s.equals("info"))
        {
            FCFSInfo  fi=new FCFSInfo(); 
        }
            }
            public static void main(String args[])
            {
                FCFSMain f1=new FCFSMain();
            }
    }