import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.util.*;
 class FCFSInfo 
{
      

          public FCFSInfo()
  {

              File fr=new File("h1.pdf");
              try{
              if(fr.exists())  
                {
                    if(Desktop.isDesktopSupported())
                         Desktop.getDesktop().open(fr);
                     else
                        JOptionPane.showMessageDialog(null,"not supported");

                }
            else{
                JOptionPane.showMessageDialog(null,"file not exists");
	}

	}catch(Exception e){}

                
          }
}
